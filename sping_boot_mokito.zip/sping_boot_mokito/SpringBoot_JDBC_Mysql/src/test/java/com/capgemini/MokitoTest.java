package com.capgemini;

import static org.hamcrest.CoreMatchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import com.capgemini.controller.JdbcController;

@RunWith(SpringRunner.class)
@WebMvcTest(value=JdbcController.class)
public class MokitoTest {
	@Autowired
	private MockMvc mockMvc;
	@MockBean
	JdbcController jdbcCon;
	@Test
	public void testJdbcController() throws Exception {
		Mockito.when(jdbcCon.select()).thenReturn("from mock");
		this.mockMvc.perform(get("/select")).andExpect(content().string("from mock"));
		
	}

}
